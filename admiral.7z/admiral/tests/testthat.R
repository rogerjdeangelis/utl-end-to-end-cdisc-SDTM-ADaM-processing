library(testthat)
library(admiral)

test_check("admiral")
